==============================
Jeisenbath.Linux Release Notes
==============================

.. contents:: Topics


v1.1.0
======

Release Summary
---------------

Released 2025-07-11

Major Changes
-------------

- add groups role
- add interfaces role
- add users role
- remove users_local role

v1.0.0
======

Release Summary
---------------

Released 2024-07-05

Major Changes
-------------

- Added role users_local for managing users and groups
