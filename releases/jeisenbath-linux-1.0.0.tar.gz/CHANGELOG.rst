==============================
Jeisenbath.Linux Release Notes
==============================

.. contents:: Topics


v1.0.0
======

Release Summary
---------------

Released 2024-07-05

Major Changes
-------------

- Added role users_local for managing users and groups
